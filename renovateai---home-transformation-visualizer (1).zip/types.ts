
export type StylePreset = 
  | 'modern' 
  | 'minimalist' 
  | 'scandinavian' 
  | 'industrial' 
  | 'luxury' 
  | 'contemporary' 
  | 'custom';

export type RoomType = 
  | 'living_room' 
  | 'bedroom' 
  | 'kitchen' 
  | 'bathroom' 
  | 'dining_room' 
  | 'office' 
  | 'hallway';

export interface MaterialItem {
  category: string;
  name: string;
  description: string;
  quantity: number;
  unit: string;
  pricePerUnit: number;
  imageUrl?: string;
}

export interface RenovationResult {
  id: string;
  imageUrl: string;
  style: StylePreset;
  roomType: RoomType;
  explanation: string;
  recommendations: string[];
  materials?: MaterialItem[];
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}
