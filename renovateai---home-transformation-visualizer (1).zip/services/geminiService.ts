
import { GoogleGenAI, Type } from "@google/genai";
import { StylePreset, MaterialItem, RoomType, ChatMessage } from "../types";

// Enhanced retry logic for 429 errors
async function withRetry<T>(fn: () => Promise<T>, maxRetries = 5, initialDelay = 3000): Promise<T> {
  let lastError: any;
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (error: any) {
      lastError = error;
      const errorMsg = (error?.message || "").toLowerCase();
      const isRateLimit = errorMsg.includes('429') || 
                          errorMsg.includes('resource_exhausted') || 
                          error?.status === 'RESOURCE_EXHAUSTED';
      
      if (isRateLimit && i < maxRetries - 1) {
        // Exponential backoff with jitter
        const delay = initialDelay * Math.pow(2, i) + Math.random() * 2000;
        console.warn(`Rate limit reached. Waiting ${Math.round(delay)}ms... (Attempt ${i + 1}/${maxRetries})`);
        await new Promise(resolve => setTimeout(resolve, delay));
        continue;
      }
      throw error;
    }
  }
  throw lastError;
}

export const transformRoom = async (
  base64Image: string, 
  style: StylePreset, 
  roomType: RoomType,
  customPrompt?: string
): Promise<{ imageUrl: string; explanation: string }> => {
  return withRetry(async () => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const roomLabels: Record<RoomType, string> = {
      living_room: "Living Room",
      bedroom: "Bedroom",
      kitchen: "Kitchen",
      bathroom: "Bathroom",
      dining_room: "Dining Room",
      office: "Home Office",
      hallway: "Hallway"
    };

    const stylePrompts: Record<StylePreset, string> = {
      modern: "Modern style: Affordable materials, clean look, neutral palette.",
      minimalist: "Minimalist: Essential furniture only, clutter-free, functional.",
      scandinavian: "Scandinavian: Light wood, cozy textures, bright airy feel.",
      industrial: "Industrial: Exposed brick/metal, darker tones, raw textures.",
      luxury: "Luxury: Premium finishes, elegant lighting, rich textures, marble/gold accents.",
      contemporary: "Mid-range Contemporary: Balanced mix of modern trends and comfort, high-quality finishes.",
      custom: customPrompt || "Custom budget renovation."
    };

    // Consolidated prompt to get everything in one go, reducing call frequency
    const prompt = `
      ACT AS: A senior Interior Architect and Material Expert.
      SPACE: ${roomLabels[roomType]}.
      DESIGN TIER: ${stylePrompts[style]}
      
      TASK 1 (Visual): Reimagine this space based on the original layout. Update flooring, wall treatments, furniture, and lighting. Preserve windows and structural columns.
      
      TASK 2 (Textual): Provide a 30-word design rationale explaining the major changes, including specific materials used (e.g. Italian marble, oak wood, satin finish paint).
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          { inlineData: { data: base64Image.split(',')[1], mimeType: 'image/png' } },
          { text: prompt }
        ]
      }
    });

    let imageUrl = '';
    let explanation = '';
    
    if (response.candidates?.[0]?.content?.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          imageUrl = `data:image/png;base64,${part.inlineData.data}`;
        } else if (part.text) {
          explanation += part.text;
        }
      }
    }

    return {
      imageUrl: imageUrl || base64Image,
      explanation: explanation.trim() || "Design tier applied successfully."
    };
  });
};

export const generateMaterialsList = async (style: StylePreset, roomType: RoomType, designContext: string): Promise<MaterialItem[]> => {
  return withRetry(async () => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Based on this design description: "${designContext}", generate a detailed shopping list.
      
      RULES:
      1. Include Paint, Flooring, Lighting, and 2 key furniture/decor pieces.
      2. Prices must be realistic estimates for the selected design tier (Luxury should be higher than Modern).
      3. Currency: INR (₹).
      
      Output exactly in JSON format.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              category: { type: Type.STRING },
              name: { type: Type.STRING },
              description: { type: Type.STRING },
              quantity: { type: Type.NUMBER },
              unit: { type: Type.STRING },
              pricePerUnit: { type: Type.NUMBER }
            },
            required: ["category", "name", "description", "quantity", "unit", "pricePerUnit"]
          }
        }
      }
    });

    try {
      return JSON.parse(response.text || "[]");
    } catch (e) {
      return [];
    }
  });
};

export const generateItemVisual = async (itemName: string, style: string): Promise<string> => {
  return withRetry(async () => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const prompt = `High-end architectural product photography: ${itemName} in ${style} style, studio lighting, isolated on white.`;
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: { parts: [{ text: prompt }] }
    });
    if (response.candidates?.[0]?.content?.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return `https://placehold.co/400x400/indigo/white?text=${encodeURIComponent(itemName)}`;
  }, 3, 4000); // More aggressive wait for individual items
};

export const analyzeRoomStructure = async (base64Image: string, roomType: RoomType): Promise<string> => {
  return withRetry(async () => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          { inlineData: { data: base64Image.split(',')[1], mimeType: 'image/png' } },
          { text: `Analyze the layout of this ${roomType}. Suggest 1 structural optimization for better flow. Max 25 words.` }
        ]
      }
    });
    return response.text || "Analysis complete.";
  });
};

export const getChatResponse = async (history: ChatMessage[], message: string): Promise<string> => {
  return withRetry(async () => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const systemInstruction = `You are Ammu, an expert Interior Design AI. Be helpful, concise, and focused on design aesthetics and material sourcing. Max 40 words per reply.`;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [
        ...history.map(m => ({ role: m.role, parts: [{ text: m.text }] })),
        { role: "user", parts: [{ text: message }] }
      ],
      config: {
        systemInstruction,
        maxOutputTokens: 200,
      }
    });

    return response.text?.trim() || "I'm here to help with your design!";
  });
};
