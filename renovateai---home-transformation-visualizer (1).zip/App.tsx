
import React, { useState, useRef, useEffect } from 'react';
import { StylePreset, RoomType, RenovationResult, MaterialItem, ChatMessage } from './types';
import { transformRoom, analyzeRoomStructure, generateMaterialsList, generateItemVisual, getChatResponse } from './services/geminiService';

const Header: React.FC = () => (
  <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
    <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-bold">R</div>
        <span className="text-xl font-bold text-slate-800">Renovate<span className="text-indigo-600">AI</span></span>
      </div>
    </div>
  </header>
);

const SectionHeading: React.FC<{ title: string; subtitle?: string }> = ({ title, subtitle }) => (
  <div className="mb-8">
    <h2 className="text-3xl font-black text-slate-900 tracking-tight">{title}</h2>
    {subtitle && <p className="text-slate-500 font-medium text-sm mt-1">{subtitle}</p>}
  </div>
);

const Footer: React.FC = () => (
  <footer className="bg-slate-50 border-t border-slate-200 py-12 mt-auto">
    <div className="max-w-7xl mx-auto px-4 text-center">
      <div className="flex items-center justify-center gap-2 mb-4">
        <div className="w-6 h-6 bg-indigo-600 rounded flex items-center justify-center text-white font-bold text-xs">R</div>
        <span className="font-bold text-slate-800 text-sm">RenovateAI</span>
      </div>
      <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest">© 2024 RenovateAI • Intelligent Interior Design</p>
    </div>
  </footer>
);

const MaterialCard: React.FC<{ 
  item: MaterialItem, 
  style: string, 
  onUpdate: (updated: MaterialItem) => void 
}> = ({ item, style, onUpdate }) => {
  const [loading, setLoading] = useState(false);

  const generateVisual = async () => {
    if (item.imageUrl && !item.imageUrl.includes('placehold.co')) return;
    setLoading(true);
    try {
      const imageUrl = await generateItemVisual(item.name, style);
      onUpdate({ ...item, imageUrl });
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const updateQty = (delta: number) => {
    const newQty = Math.max(0, item.quantity + delta);
    onUpdate({ ...item, quantity: newQty });
  };

  const itemTotal = item.quantity * item.pricePerUnit;

  return (
    <div className="flex flex-col sm:row gap-4 p-4 bg-white rounded-2xl border border-slate-100 hover:border-indigo-100 transition-all shadow-sm">
      <div className="w-full sm:w-24 h-24 flex-shrink-0 bg-slate-50 rounded-xl overflow-hidden relative border border-slate-100">
        {item.imageUrl ? (
          <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" loading="lazy" />
        ) : (
          <button onClick={generateVisual} className="w-full h-full flex items-center justify-center text-indigo-600 hover:bg-indigo-50 transition-colors">
            {loading ? <div className="w-5 h-5 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></div> : <span className="text-[10px] font-bold uppercase">View</span>}
          </button>
        )}
      </div>
      <div className="flex-grow flex flex-col justify-between">
        <div className="flex justify-between items-start">
          <div className="max-w-[70%]">
            <h4 className="font-bold text-slate-900 text-sm truncate">{item.name}</h4>
            <p className="text-[8px] font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded inline-block mt-1 uppercase tracking-wider">{item.category}</p>
          </div>
          <div className="text-right">
            <span className="text-xs font-black text-slate-900">₹{item.pricePerUnit.toLocaleString()}</span>
          </div>
        </div>
        <div className="flex items-center justify-between mt-2">
          <div className="flex items-center bg-slate-100 rounded-lg p-1 border border-slate-200">
            <button onClick={() => updateQty(-1)} className="w-5 h-5 flex items-center justify-center text-slate-400 hover:text-red-500 font-bold">×</button>
            <span className="px-3 font-bold text-[11px] text-slate-900">{item.quantity}</span>
            <button onClick={() => updateQty(1)} className="w-5 h-5 flex items-center justify-center text-slate-400 hover:text-indigo-600 font-bold">+</button>
          </div>
          <span className="text-sm font-black text-indigo-600">₹{itemTotal.toLocaleString()}</span>
        </div>
      </div>
    </div>
  );
};

const ChatBot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isLoading]);

  const handleSendMessage = async () => {
    const textToProcess = inputValue.trim();
    if (!textToProcess || isLoading) return;
    
    const userMsg: ChatMessage = { role: 'user', text: textToProcess };
    setMessages(prev => [...prev, userMsg]);
    setInputValue('');
    setIsLoading(true);

    try {
      const responseText = await getChatResponse([...messages, userMsg], textToProcess);
      setMessages(prev => [...prev, { role: 'model', text: responseText }]);
    } catch (error: any) {
      setMessages(prev => [...prev, { role: 'model', text: "I'm processing a lot of ideas right now. Please give me a moment!" }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-[200]">
      {!isOpen ? (
        <button 
          onClick={() => setIsOpen(true)}
          className="w-16 h-16 bg-indigo-600 rounded-full flex items-center justify-center text-white shadow-2xl hover:scale-110 active:scale-95 transition-all group"
        >
          <div className="relative">
            <svg className="w-8 h-8 group-hover:rotate-12 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" /></svg>
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 border-2 border-white rounded-full"></span>
          </div>
        </button>
      ) : (
        <div className="w-80 sm:w-96 h-[500px] bg-white rounded-[2.5rem] shadow-[0_20px_50px_rgba(0,0,0,0.15)] border border-slate-100 flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-8 duration-300">
          <div className="p-5 bg-indigo-600 text-white flex justify-between items-center shadow-lg">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-indigo-500 rounded-2xl flex items-center justify-center text-white font-black shadow-inner border border-indigo-400">A</div>
              <div>
                <span className="block font-black text-base uppercase tracking-wider">Ammu</span>
                <span className="block text-[10px] text-indigo-200 font-bold uppercase tracking-widest">Design Assistant</span>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="hover:bg-white/20 p-2 rounded-full transition-colors active:scale-90">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </div>
          
          <div className="flex-grow overflow-y-auto p-5 space-y-4 bg-slate-50/30 custom-scrollbar">
            {messages.length === 0 && (
              <div className="text-center mt-12 px-6">
                <p className="text-sm text-slate-600 font-black uppercase tracking-tight">Welcome!</p>
                <p className="text-xs text-slate-400 mt-2 font-medium">Ask me about materials, styles, or specific design tips.</p>
              </div>
            )}
            {messages.map((msg, i) => (
              <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] px-5 py-3 rounded-2xl text-[12px] font-bold shadow-sm ${
                  msg.role === 'user' ? 'bg-indigo-600 text-white' : 'bg-white text-slate-700'
                }`}>
                  {msg.text}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white px-5 py-3 rounded-2xl flex gap-2 items-center">
                  <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce"></div>
                </div>
              </div>
            )}
            <div ref={chatEndRef}></div>
          </div>

          <div className="p-5 border-t border-slate-100 bg-white">
            <div className="bg-slate-50 rounded-2xl p-2 flex items-center gap-2 border border-slate-100">
              <input 
                type="text" 
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder="Ask Ammu..."
                className="flex-grow bg-transparent border-none px-2 py-2 text-[13px] font-bold outline-none"
              />
              <button 
                onClick={handleSendMessage}
                disabled={!inputValue.trim() || isLoading}
                className="w-11 h-11 bg-indigo-600 text-white rounded-xl flex items-center justify-center disabled:opacity-40"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const App: React.FC = () => {
  const [beforeImage, setBeforeImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [results, setResults] = useState<RenovationResult[]>([]);
  const [selectedRoom, setSelectedRoom] = useState<RoomType>('living_room');
  const [selectedStyle, setSelectedStyle] = useState<StylePreset>('modern');
  const [error, setError] = useState<string | null>(null);
  const [isMaterialsLoading, setIsMaterialsLoading] = useState(false);
  const [structuralInsight, setStructuralInsight] = useState<string | null>(null);

  const howItWorksRef = useRef<HTMLDivElement>(null);
  const pricingRef = useRef<HTMLDivElement>(null);
  const transformationRef = useRef<HTMLDivElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setBeforeImage(reader.result as string);
        setResults([]);
        setStructuralInsight(null);
        setError(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const startRenovation = async () => {
    if (!beforeImage) return;
    setIsAnalyzing(true);
    setError(null);
    setStructuralInsight(null);
    try {
      // Single consolidated call to reduce concurrent hits
      const { imageUrl, explanation } = await transformRoom(beforeImage, selectedStyle, selectedRoom);
      
      const newResult: RenovationResult = {
        id: Date.now().toString(),
        imageUrl,
        style: selectedStyle,
        roomType: selectedRoom,
        explanation,
        recommendations: []
      };
      setResults([newResult]);
    } catch (err: any) {
      setError("High demand detected. I'm retrying with a smarter approach—please wait a few more seconds!");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const fetchStructuralAnalysis = async () => {
    if (!beforeImage || structuralInsight) return;
    try {
      const insight = await analyzeRoomStructure(beforeImage, selectedRoom);
      setStructuralInsight(insight);
    } catch (e) {
      setError("Analysis limit reached. Try again in 30 seconds.");
    }
  };

  const fetchMaterials = async () => {
    if (results.length === 0 || results[0].materials || isMaterialsLoading) return;
    setIsMaterialsLoading(true);
    try {
      const materials = await generateMaterialsList(results[0].style, results[0].roomType, results[0].explanation);
      setResults(prev => prev.map(r => r.id === results[0].id ? { ...r, materials } : r));
    } catch (err: any) {
      setError("Rate limit reached for pricing data. Retrying...");
    } finally {
      setIsMaterialsLoading(false);
    }
  };

  const handleUpdateMaterial = (idx: number, updated: MaterialItem) => {
    setResults(prev => prev.map(r => {
      if (r.id === results[0].id && r.materials) {
        const newMaterials = [...r.materials];
        newMaterials[idx] = updated;
        return { ...r, materials: newMaterials };
      }
      return r;
    }));
  };

  const totalCartCost = results[0]?.materials?.reduce((acc, item) => acc + (item.quantity * item.pricePerUnit), 0) || 0;

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Header />

      <main className="flex-grow max-w-6xl mx-auto px-4 py-8 w-full">
        <div className="flex justify-center gap-4 mb-12">
          <button onClick={() => howItWorksRef.current?.scrollIntoView({ behavior: 'smooth' })} className="px-6 py-3 rounded-full bg-slate-100 font-bold text-xs uppercase hover:bg-indigo-600 hover:text-white transition-all shadow-sm">How It Works</button>
          <button onClick={() => { pricingRef.current?.scrollIntoView({ behavior: 'smooth' }); fetchMaterials(); }} className="px-6 py-3 rounded-full bg-slate-100 font-bold text-xs uppercase hover:bg-indigo-600 hover:text-white transition-all shadow-sm">Budget Pricing</button>
        </div>

        <div ref={transformationRef} className="mb-24 scroll-mt-20">
          <SectionHeading title="Renovate Room" subtitle="AI-driven interiors tailored to your space." />
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            <div className="lg:col-span-1 space-y-6">
              {/* Step 1: Upload */}
              <div className="bg-slate-50 p-6 rounded-3xl border border-slate-100 shadow-sm">
                <h4 className="font-bold text-slate-800 mb-4 text-xs uppercase tracking-widest">Step 1: Upload Photo</h4>
                <div className="relative border-2 border-dashed border-slate-200 rounded-2xl p-6 text-center bg-white hover:border-indigo-300 transition-colors">
                  <input type="file" accept="image/*" onChange={handleImageUpload} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />
                  {beforeImage ? <img src={beforeImage} className="max-h-40 mx-auto rounded-lg shadow-md" /> : <div className="py-8 text-slate-300 font-bold text-xs">CLICK TO UPLOAD IMAGE</div>}
                </div>
              </div>

              {/* Step 2: Room Selection */}
              <div className="bg-slate-50 p-6 rounded-3xl border border-slate-100 shadow-sm">
                <h4 className="font-bold text-slate-800 mb-4 text-xs uppercase tracking-widest">Step 2: Room Type</h4>
                <div className="grid grid-cols-2 gap-2">
                  {(['living_room', 'bedroom', 'kitchen', 'bathroom'] as RoomType[]).map(room => (
                    <button 
                      key={room} 
                      onClick={() => setSelectedRoom(room)} 
                      className={`px-2 py-2.5 rounded-xl text-[9px] font-black uppercase border transition-all ${selectedRoom === room ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-slate-500 border-slate-100 hover:border-indigo-200'}`}
                    >
                      {room.replace('_', ' ')}
                    </button>
                  ))}
                </div>
              </div>

              {/* Step 3: Design Tier */}
              <div className="bg-slate-50 p-6 rounded-3xl border border-slate-100 shadow-sm">
                <h4 className="font-bold text-slate-800 mb-4 text-xs uppercase tracking-widest">Step 3: Design Style</h4>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: 'modern', label: 'Modern' },
                    { id: 'contemporary', label: 'Mid-range' },
                    { id: 'luxury', label: 'Luxury' },
                    { id: 'minimalist', label: 'Minimalist' },
                    { id: 'scandinavian', label: 'Scandinavian' },
                    { id: 'industrial', label: 'Industrial' }
                  ].map(style => (
                    <button 
                      key={style.id} 
                      onClick={() => setSelectedStyle(style.id as StylePreset)} 
                      className={`px-2 py-2.5 rounded-xl text-[9px] font-black uppercase border transition-all ${selectedStyle === style.id ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-slate-500 border-slate-100 hover:border-indigo-200'}`}
                    >
                      {style.label}
                    </button>
                  ))}
                </div>
              </div>

              <button 
                onClick={startRenovation} 
                disabled={!beforeImage || isAnalyzing} 
                className={`w-full py-5 rounded-2xl font-black text-sm uppercase tracking-widest transition-all ${!beforeImage || isAnalyzing ? 'bg-slate-100 text-slate-300' : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-xl shadow-indigo-100 active:scale-[0.98]'}`}
              >
                {isAnalyzing ? 'Processing Design...' : 'Visualize Transformation'}
              </button>
              {error && <div className="p-4 bg-orange-50 border border-orange-100 rounded-2xl text-center text-orange-700 text-[10px] font-bold uppercase leading-relaxed tracking-wider">{error}</div>}
            </div>

            <div className="lg:col-span-2">
              {isAnalyzing ? (
                <div className="bg-slate-50 h-full min-h-[500px] rounded-[2.5rem] flex flex-col items-center justify-center border border-slate-100">
                  <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mb-6"></div>
                  <p className="text-slate-400 font-bold text-xs uppercase tracking-widest text-center px-12 leading-loose animate-pulse">
                    Ammu is carefully selecting materials to match your style tier...
                  </p>
                </div>
              ) : results.length > 0 ? (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="relative rounded-[2rem] overflow-hidden border border-slate-100 aspect-square shadow-sm">
                      <div className="absolute top-4 left-4 z-10 bg-black/50 backdrop-blur-md px-3 py-1.5 rounded-full text-[9px] font-black text-white uppercase tracking-widest">Original</div>
                      <img src={beforeImage!} className="w-full h-full object-cover" />
                    </div>
                    <div className="relative rounded-[2rem] overflow-hidden border border-indigo-100 shadow-2xl aspect-square">
                      <div className="absolute top-4 left-4 z-10 bg-indigo-600 px-3 py-1.5 rounded-full text-[9px] font-black text-white uppercase tracking-widest">Transformed</div>
                      <img src={results[0].imageUrl} className="w-full h-full object-cover" />
                    </div>
                  </div>
                  <div className="bg-slate-50 p-8 rounded-[2rem] border border-slate-100 shadow-inner">
                    <div className="flex justify-between items-start mb-4">
                      <h5 className="font-black text-slate-800 text-[10px] uppercase tracking-[0.2em]">Ammu's Design Rationale</h5>
                      {!structuralInsight && (
                        <button onClick={fetchStructuralAnalysis} className="text-[9px] font-black text-indigo-600 uppercase border border-indigo-200 px-3 py-1 rounded-full hover:bg-indigo-50 transition-colors">
                          Get Structural Insight
                        </button>
                      )}
                    </div>
                    <div className="text-slate-600 text-sm font-medium space-y-3 whitespace-pre-wrap leading-relaxed">
                      {results[0].explanation}
                      {structuralInsight && (
                        <div className="mt-4 p-4 bg-white rounded-xl border border-slate-200 animate-in fade-in slide-in-from-top-2">
                           <span className="block text-[9px] font-black text-indigo-600 uppercase mb-1">Structural Recommendation</span>
                           <p className="italic text-slate-500">{structuralInsight}</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-slate-50 h-full min-h-[500px] rounded-[2.5rem] flex flex-col items-center justify-center border border-slate-100 border-dashed">
                  <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mb-4">
                    <svg className="w-8 h-8 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                  </div>
                  <p className="text-slate-300 font-bold text-xs uppercase tracking-[0.15em]">Upload a photo to begin renovation</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* How It Works Section */}
        <div ref={howItWorksRef} className="mb-24 scroll-mt-20 border-t border-slate-100 pt-16">
          <SectionHeading title="How It Works" subtitle="Step-by-step to your redesigned space." />
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { num: "01", title: "Capture", desc: "Upload your room photo. We detect architectural bounds and light sources." },
              { num: "02", title: "Config", desc: "Select room type and a design style ranging from Mid-range to Luxury." },
              { num: "03", title: "Visualize", desc: "Ammu generates a professional 3D-informed design preview." },
              { num: "04", title: "Source", desc: "Access a precise bill of materials with localized market pricing." }
            ].map(step => (
              <div key={step.num} className="bg-white p-8 rounded-3xl border border-slate-100 hover:border-indigo-200 transition-all shadow-sm group">
                <span className="text-indigo-600 font-black text-4xl opacity-10 group-hover:opacity-100 transition-opacity duration-500">{step.num}</span>
                <h4 className="font-black text-slate-900 mt-4 mb-2 uppercase text-xs tracking-wider">{step.title}</h4>
                <p className="text-slate-500 text-[13px] font-medium leading-relaxed">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Pricing Section */}
        <div ref={pricingRef} className="mb-24 scroll-mt-20 border-t border-slate-100 pt-16">
          <SectionHeading title="Estimated Budget" subtitle="Market-linked pricing for the selected design tier (INR)." />
          {isMaterialsLoading ? (
            <div className="py-24 text-center flex flex-col items-center bg-slate-50 rounded-[3rem] border border-slate-100">
              <div className="w-10 h-10 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mb-6"></div>
              <p className="text-slate-400 font-bold text-[10px] uppercase tracking-widest">Calculating material costs...</p>
            </div>
          ) : results.length > 0 && results[0].materials ? (
            <div className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {results[0].materials.map((item, idx) => (
                  <MaterialCard key={idx} item={item} style={results[0].style} onUpdate={(u) => handleUpdateMaterial(idx, u)} />
                ))}
              </div>
              <div className="bg-slate-900 text-white p-10 rounded-[3rem] flex flex-col md:row items-center justify-between shadow-2xl gap-8">
                <div>
                  <span className="block text-[10px] font-black text-indigo-400 uppercase tracking-[0.3em] mb-2">Estimated Investment</span>
                  <span className="text-5xl font-black tabular-nums">₹{totalCartCost.toLocaleString()}</span>
                  <p className="text-[10px] text-slate-500 font-bold mt-2 uppercase tracking-widest">Prices may vary based on local labor rates</p>
                </div>
                <button onClick={() => window.open('https://www.flipkart.com', '_blank')} className="bg-indigo-600 hover:bg-indigo-700 text-white px-10 py-5 rounded-2xl font-black uppercase text-sm transition-all active:scale-95 shadow-xl shadow-indigo-900/40 tracking-widest">Checkout Materials</button>
              </div>
            </div>
          ) : (
            <div className="bg-slate-50 py-24 rounded-[3rem] text-center border border-slate-100 border-dashed">
              <p className="text-slate-300 font-bold text-xs uppercase tracking-widest">Generate a design to view the pricing guide</p>
            </div>
          )}
        </div>
      </main>

      <ChatBot />
      <Footer />
    </div>
  );
};

export default App;
